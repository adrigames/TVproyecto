package rpg;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Animation;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.tiled.TiledMap; 
/**
 *
 * @author sergio
 */
public class RPG extends BasicGame {
    private TiledMap city;
    private SpriteSheet sprite;
    private float jugadorX, jugadorY;
    private Animation jugador, up, down, left, right;
    private boolean[][] blocked;
    private float tileWidth;
    private float tileHeight;
    private static final int SIZE = 20;
    
    public RPG(){
        super("RPG");
    }


    public static void main(String[] args) {
        try {
            AppGameContainer app;
            app = new AppGameContainer(new RPG());
            app.setDisplayMode(1200, 600, false);
            app.setShowFPS(false);
            app.start();
  }
  catch (SlickException e)
  {
   e.printStackTrace();
  }
 }
 @Override
 public void init(GameContainer gc) throws SlickException {
    city = new TiledMap("data/city.tmx");
    sprite = new SpriteSheet("data/sprite1.png",31,33);
    down = new Animation(sprite,0,0,2,0,true,150,false);
    left = new Animation(sprite,0,1,2,1,true,150, false);
    right = new Animation(sprite,0,2,2,2,true,150, false);
    up = new Animation(sprite,0,3,2,3,true,150,false);
    jugador = right;
    jugadorX = 100; jugadorY = 100;
    blocked = new boolean[city.getWidth()][city.getHeight()];
    for (int x = 0; x<city.getWidth(); x++){
          System.out.print("F:"+x+"");
        for (int y = 0; y<city.getHeight(); y++){
            blocked[x][y] = (city.getTileId(x, y, 0)!=0);
            System.out.print(blocked[x][y]);
            }
            System.out.println();}
    tileWidth = city.getTileWidth();
    tileHeight =  city.getTileHeight();
    System.out.println(tileWidth);
    System.out.println(tileHeight);
 }
 
@Override
public void update(GameContainer container, int delta) throws SlickException {
    float jugadorAnteriorX = jugadorX; float jugadorAnteriorY = jugadorY;
        
    Input input = container.getInput();
    if (input.isKeyDown(Input.KEY_UP)) {
         jugador = up;
         jugador.update(delta);
         jugadorY -= delta * 0.1f;
    }
    else if (input.isKeyDown(Input.KEY_DOWN))
{
    jugador = down;
    jugador.update(delta);
    jugadorY += delta * 0.1f;
}
else if (input.isKeyDown(Input.KEY_LEFT))
{
    jugador = left;
    jugador.update(delta);
    jugadorX -= delta * 0.1f;
}
else if (input.isKeyDown(Input.KEY_RIGHT))
{
    jugador = right;
    jugador.update(delta);
    jugadorX += delta * 0.1f;
}
int a = (int)((jugadorX+8+jugador.getWidth())/tileWidth);
int b = (int)((jugadorY+jugador.getHeight())/ tileHeight);
int c = (int)((jugadorX-8+jugador.getWidth())/tileWidth);
int d = (int)((jugadorY+jugador.getHeight())/tileHeight);
if (blocked[a][b] || blocked[c][d]) {
        jugadorX = jugadorAnteriorX;
        jugadorY = jugadorAnteriorY;
        }}
 
 @Override
 public void render(GameContainer gc, Graphics g) throws SlickException
 {
  city.render(-10,-9);
  jugador.draw(jugadorX, jugadorY);
  g.drawRect(jugadorX, jugadorY, jugador.getWidth(), jugador.getHeight());
 }
 
}

    
    

